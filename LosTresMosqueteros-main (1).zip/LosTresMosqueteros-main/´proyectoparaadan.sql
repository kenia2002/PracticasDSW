-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.24-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para proyectodsw
CREATE DATABASE IF NOT EXISTS `proyectodsw` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `proyectodsw`;

-- Volcando estructura para tabla proyectodsw.datos
CREATE TABLE IF NOT EXISTS `datos` (
  `nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `edad` int(11) NOT NULL,
  `selectSexo` varchar(50) NOT NULL,
  `selectCiudad` varchar(50) NOT NULL,
  `Telefono` int(11) NOT NULL,
  `selectTransporte` varchar(50) NOT NULL,
  `comentarios` varchar(100) NOT NULL,
  `selectCamisa` varchar(50) NOT NULL,
  `selectTalla` varchar(50) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla proyectodsw.datos: ~37 rows (aproximadamente)
INSERT INTO `datos` (`nombre`, `Apellido`, `edad`, `selectSexo`, `selectCiudad`, `Telefono`, `selectTransporte`, `comentarios`, `selectCamisa`, `selectTalla`, `id`) VALUES
	('Adan', 'Preciado', 21, '1', '1', 2147483647, '1', 'comentario', '1', '1', 1),
	('Adan Alberto', 'Preciado Mascareño', 21, '1', '0', 2147483647, '0', 'COMENTARIO DOS', '0', '0', 2),
	('Jesus', 'Hernandez', 21, '1', 'Tijuana', 2147483647, 'Si', '', 'Si', 'mediana', 3),
	('Jesus', 'Hernandez', 21, '1', 'Tijuana', 2147483647, 'Si', '', 'Si', 'mediana', 4),
	('pepe', 'dcsd', 19, 'Masculino', 'Tijuana', 1234567891, 'Si', 'csdcdscsdc', 'Si', 'grande', 5),
	('mano', 'perez', 60, 'Masculino', 'Tijuana', 1234567891, 'Si', 'sdsad', 'No', 'chica', 7),
	('aaaaa', 'aaaa', 22, 'Masculino', 'Tijuana', 0, 'Si', 'as', 'No', 'chica', 8),
	('aaaaa', 'aaaa', 22, 'Masculino', 'Tijuana', 0, 'Si', 'as', 'No', 'chica', 9),
	('pepe', 'pica', 55, 'Masculino', 'Tijuana', 2147483647, 'No', 'creo que ya esta', 'No', 'chica', 10),
	('pepe', 'pica', 55, 'Masculino', 'Tijuana', 2147483647, 'No', 'creo que ya esta', 'No', 'chica', 11),
	('juan', 'delamar', 33, 'Masculino', 'Tijuana', 2147483647, 'Si', 'as', 'No', 'chica', 12),
	('juan', 'delamar', 33, 'Masculino', 'Tijuana', 2147483647, 'Si', 'as', 'No', 'chica', 13),
	('finall', 'logro', 54, 'Masculino', 'Tijuana', 1234567891, 'Si', 'vvvv', 'No', 'chica', 14),
	('finall', 'logro', 54, 'Masculino', 'Tijuana', 1234567891, 'Si', 'vvvv', 'No', 'chica', 15),
	('yaaaaa', 'Hernandez', 39, 'Masculino', 'Tijuana', 1234567891, 'Si', 'we', 'No', '', 16),
	('yaaaaa', 'Hernandez', 39, 'Masculino', 'Tijuana', 1234567891, 'Si', 'we', 'No', '', 17),
	('jajajaja', 'jejejejeje', 34, 'Femenino', 'Tijuana', 2147483647, 'Si', 'sdsds', 'No', '', 18),
	('gggggg', 'fffff', 21, 'Masculino', 'Tijuana', 1234567891, 'No', 'fsdfsdf', 'No', '', 19),
	('uwu', 'Preciado', 21, 'Masculino', 'Tijuana', 2147483647, 'Si', 'wewe', 'No', '', 20),
	('gansito', 'perez', 19, 'Masculino', 'Tijuana', 1111111111, 'Si', '', 'No', '', 21),
	('mayu', 'scula', 21, 'Masculino', 'Tijuana', 2147483647, 'Si', 'aasddsa', 'Si', 'grande', 22),
	('qwqwqww', 'wqwqwq', 21, 'Masculino', 'Cd_Juarez', 2147483647, 'Si', 'qdwqd', 'Si', 'chica', 23),
	('qwqwqww', 'wqwqwq', 21, 'Masculino', 'Cd_Juarez', 2147483647, 'Si', 'qdwqd', 'Si', 'chica', 24),
	('qwqwqww', 'wqwqwq', 21, 'Masculino', 'Cd_Juarez', 2147483647, 'Si', 'qdwqd', 'Si', 'chica', 25),
	('qw1', 'asdd', 21, 'Masculino', 'Tijuana', 1232132131, 'Si', 'asdsd', 'Si', 'chica', 26),
	('swdw', 'sadasdsd', 20, 'Masculino', 'CDMX', 2147483647, 'Si', 'zvdv3', 'Si', 'grande', 27),
	('ASCSC', 'ASCCSC', 20, 'Masculino', 'Tijuana', 1234567891, 'Si', 'ASCSAC', 'Si', 'chica', 28),
	('TTTTTT', 'TTTTTT', 20, 'Masculino', 'Tijuana', 2147483647, 'Si', 'FVFDGD', 'Si', 'chica', 29),
	('LU', 'HERNANDEZ', 21, 'Femenino', 'Tijuana', 111111112, 'No', 'YAAA', 'Si', 'chica', 30),
	('JESUS', 'JESUS', 21, 'Masculino', 'Tijuana', 1591591591, 'Si', 'NOPUEDO', 'Si', 'chica', 31),
	('NACHO', 'CONQUESO', 22, 'Femenino', 'Tijuana', 2147483647, 'Si', 'PORFAVOR', 'Si', 'mediana', 32),
	('TACOS', 'DEMOLE', 50, 'Masculino', 'Tijuana', 2147483647, 'No', 'EDEW', 'No', 'chica', 33),
	('VIVIVIVIVIVIV', 'VOVOVOVOV', 21, 'Masculino', 'Tijuana', 2147483647, 'Si', 'EWFWEF', 'Si', 'chica', 34),
	('VIVIVIVIVIVIV', 'VOVOVOVOV', 21, 'Masculino', 'Tijuana', 2147483647, 'Si', 'EWFWEF', 'Si', 'chica', 35),
	('QUEWEV', 'ESTOY', 21, 'Masculino', 'Tijuana', 1234567891, 'Si', 'ASD', 'Si', 'chica', 36),
	('QUEWEV', 'ESTOY', 21, 'Masculino', 'Tijuana', 1234567891, 'Si', 'ASD', 'Si', 'chica', 37),
	('YAMORIR', 'ENPAZ', 18, 'Masculino', 'Tijuana', 2147483647, 'Si', 'YAAAAERRRR', 'Si', 'grande', 38);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
