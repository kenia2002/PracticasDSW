<?php
$servidor = "localhost";
$usuario = "root";
$clave = "";
$bd = "proyectodsw";
$conexion = mysqli_connect ($servidor, $usuario, $clave, $bd);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin 🐱‍🚀 🐱‍👤 🐱‍🚀</title>
    <link rel="stylesheet" href="principal.css">
    
</head>
<body>

    <!--

 -->

      <header class="header">
        <div class="logo">
            <img src="logo.jpg" alt="Logo de la marca">
        </div>
        <nav>
           <ul class="nav-links">
            <li><a href="Index.html">INICIO</a></li>
            <li><a href="Historia.html">HISTORIA</a></li>
            <li><a href="LugaresTuristicos.html">LUGARES TURISTICOS</a></li>
            <li><a href="PlatillosTipicos.html">PLATILLOS TIPICOS</a></li>
            <li><a href="Registro.php">REGISTRO</a></li>
           
            <li><a href="Admin.html">ADMIN</a></li>
           </ul>            
        </nav>
        <a class="btn" href="contacto.html"><button>Contacto</button></a>
    </header>
<h1>Admin con informacion clasificada</h1>


</body>
</html>

<?php
// Realizar la consulta
$sql = "SELECT * FROM datos";
$result = $conexion->query($sql);

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Mostrar los datos
    echo "<table border=1><tr><th>ID</th><th>Nombre</th><th>Apellido</th><th>Edad</th><th>Sexo</th><th>Teléfono</th><th>Transporte</th><th>Comentarios</th><th>Camisa</th><th>Talla</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"] . "</td><td>" . $row["nombre"] . "</td><td>" . $row["Apellido"] . "</td><td>" . $row["edad"] . "</td><td>" . $row["selectSexo"] . "</td><td>" . $row["Telefono"] . "</td><td>" . $row["selectTransporte"] . "</td><td>" . $row["comentarios"] . "</td><td>" . $row["selectCamisa"] . "</td><td>" . $row["selectTalla"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No se encontraron resultados";
}

// Cerrar la conexión
$conexion->close();
?>