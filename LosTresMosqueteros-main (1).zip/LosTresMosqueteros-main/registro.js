/*function manejarCambioCamisa() {
    // Obtener el valor seleccionado
    var seleccionCamisa = document.getElementById("selectCamisa").value;
    // Obtener el campo de talla
    var campoTalla = document.getElementById("campoTalla");
    var selectTalla = document.getElementById("selectTalla");
  
    // Mostrar u ocultar el campo de talla según la selección
    if (seleccionCamisa === "Si") {
      campoTalla.style.display = "table-row";
    } else {
      campoTalla.style.display = "none";
      // Si selecciona "No", establecer el valor de "ninguna" en el campo de talla
      selectTalla.value = "ninguna";
    }
  }
  
  // Agregar un event listener al cambio de la selección de camisa
  document.getElementById("selectCamisa").addEventListener("change", manejarCambioCamisa);
*/
/*
function manejarCambioCamisa() {
    // Obtener el valor seleccionado
    var seleccionCamisa = document.getElementById("selectCamisa").value;
    // Obtener el campo de talla
    var campoTalla = document.getElementById("campoTalla");
    var selectTalla = document.getElementById("selectTalla");

    // Mostrar u ocultar el campo de talla según la selección
    if (seleccionCamisa === "Si") {
      campoTalla.style.display = "table-row";
    } else {
      campoTalla.style.display = "none";
      selectTalla.value = "";
      // Si selecciona "No", no necesitas establecer un valor específico en el campo de talla
      selectTalla.value = ""; // o puedes omitir esta línea
    }
  }
*/
  function manejarCambioCamisa() {
    // Obtener el valor seleccionado
    var seleccionCamisa = document.getElementById("selectCamisa").value;
    // Obtener el campo de talla
    var campoTalla = document.getElementById("campoTalla");

    // Mostrar u ocultar el campo de talla según la selección
    if (seleccionCamisa === "Si") {
        campoTalla.style.display = "table-row";
    } else {
        campoTalla.style.display = "none";
        // Si selecciona "No", puedes reiniciar el valor de selectTalla
        document.getElementById("selectTalla").value = "ninguna";
    }
}

// Agregar un event listener al cambio de la selección de camisa
document.getElementById("selectCamisa").addEventListener("change", manejarCambioCamisa);

// Llamar a la función al cargar la página para establecer el estado inicial
manejarCambioCamisa();