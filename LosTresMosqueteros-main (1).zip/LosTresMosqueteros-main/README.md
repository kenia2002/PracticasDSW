# LosTresMosqueteros

Lineamientos proyecto final:
-Individual: Se debe seleccionar un lugar de su preferencia para ofrecer un tour
vacacional al lugar seleccionado. Posteriormente se debe crear un sitio web que
contenga las pestañas de: Inicio,historia del lugar, lugares turísticos, comida típica,
contacto del creador, formulario registro y extras que considere agregar. (utilice
imágenes, videos, textos, etc. y herramientas que considere para hacer visualmente
más atractivo el sitio)
En equipos: agregar pestaña admin a todo lo anterior, la pestaña admin debe
permitir loguearse con usuario y contraseña a otra pestaña que muestre los usuarios
registrados.
Documentación del sitio:
● Listado de requerimientos(validaciones efectuadas en los campos del
formulario, despliegue de pestañas, guardar y ver en base de datos, etc)
● Manual de usuario ( interfaz con capturas )
-El código fuente del sitio debe estar documentado.
Validaciones o restricciones del formulario registro:
Todos los campos deben estar validados con js, en algunas cajas solo números o
texto. Si el usuario selecciona camisa = si, debe desplegarse un campo en el
formulario para elegir talla, si camisa = no, el campo de talla no se despliega y en la
BD debe insertarse en el campo talla “NINGUNA”. La edad debe estar entre 18 y 60
años de edad, todos los campos son requeridos. Los campos deberán verse e
insertarse en mayúsculas, cuando el usuario envíe el formulario debe aparecer un
mensaje indicando que fue capturado con éxito o de caso contrario indicar que no
se pudieron capturar, posteriormente del mensaje la página debe redireccionar a la
página de inicio. (Si considera otros campos por agregar posee total libertad de
hacerlo)
- El sitio web creado debe estar alojado en un host gratuito o GIT (Si el sitio es
alojado en GIT, realizar un manual de usuario del proceso que se debe seguir para
subirlo a un host gratuito y otro sobre GIT).
- Presentar el sitio al grupo.
Rúbrica:
1. El diseño visual tiene un valor de 10 puntos.
2. Contenido del sitio y validaciones tiene un valor de 20 puntos.
3. La documentación del sitio tiene un valor de 10 puntos.