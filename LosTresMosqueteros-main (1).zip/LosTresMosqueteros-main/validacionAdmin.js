// Array de usuarios y contraseñas (esto es solo un ejemplo, no lo uses en producción)
var usuarios = [
    { usuario: "chuy", contrasena: "123" },
    { usuario: "admin2", contrasena: "contrasena2" },
    // ... más usuarios ...
];

function validarCredenciales() {
    // Obtener valores de usuario y contraseña
    var username = document.getElementsByName("usuario")[0].value;
    var password = document.getElementsByName("contrasena")[0].value;

    // Verificar si las credenciales son correctas
    var credencialesCorrectas = false;
    for (var i = 0; i < usuarios.length; i++) {
        if (usuarios[i].usuario === username && usuarios[i].contrasena === password) {
            credencialesCorrectas = true;
            break;
        }
    }

    // Mostrar el resultado
    if (credencialesCorrectas) {
        alert("Inicio de sesión exitoso");
        // Redirigir a la página bienvenido.html o realizar otras acciones
        window.location.href = "AdminAdentro.php";
    } else {
        alert("Usuario o contraseña incorrectos");
    }
}