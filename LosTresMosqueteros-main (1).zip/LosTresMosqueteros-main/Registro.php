<?php
$servidor = "localhost";
$usuario = "root";
$clave = "";
$bd = "proyectodsw";
$conexion = mysqli_connect ($servidor, $usuario, $clave, $bd);



if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRO 🐱‍🚀 🐱‍👤 🐱‍🚀</title>
    <link rel="stylesheet" href="principal.css">
    <link rel="stylesheet" href="axel.css">
    
</head>
<body>

    <!--

 -->

      <header class="header">
        <div class="logo">
            <img src="logo.jpg" alt="Logo de la marca">
        </div>
        <nav>
           <ul class="nav-links">
            <li><a href="Index.html">INICIO</a></li>
            <li><a href="Historia.html">NOSOTROS</a></li>
            <li><a href="LugaresTuristicos.html">LUGARES TURISTICOS</a></li>
            <li><a href="PlatillosTipicos.html">PLATILLOS TIPICOS</a></li>
            <li><a href="Registro.php">REGISTRO</a></li>
          
            <li><a href="Admin.html">ADMIN</a></li>
           </ul>            
        </nav>
        <a class="btn" href="contacto.html"><button>Contacto</button></a>
    </header>




<center>
    <form action="registro.php" method="post" onsubmit="return validarFormulario()">
    <div class="waviy">
    <span style="--i:1">Formulario</span>
    <span style="--i:2">de</span>
    <span style="--i:3">registro</span>
   </div>
   <br>
   
<table cellpadding="10" border="2">
<tr>

<td>Nombre:</td>
<td><input name="nombre" type="text" maxlength="50" placeholder="Coloque nombre" oninput="this.value = this.value.toUpperCase()" pattern="[A-Za-z]+" title="Este campo solo debe contener letras." required/></td>

<td>Apellido:</td>
<td><input name="Apellido" type="text" maxlength="50" placeholder="Apellido" oninput="this.value = this.value.toUpperCase()" pattern="[A-Za-z]+" title="Este campo solo debe contener letras." required/></td>

</tr>

<tr>

    <td>Edad:</td>
    <td><input name="edad" type="number" min="18" max="60" required/></td>
    
    <td>Sexo:</td>
    <td><select name="selectSexo">
        <option value="Masculino">Masculino</option>
        <option value="Femenino">Femenino</option>
    
      </select></td>
    </tr>

<tr>

<td>Ciudad:</td>
<td><select name="selectCiudad" required>
    <option value="Tijuana">Tijuana</option>
    <option value="Leon">Leon</option>
    <option value="Zapopan">Zapopan</option>
    <option value="CDMX">Ciudad de mexico</option>
    <option value="Cd_Juarez">Ciudad juarez</option>
  </select></td>

  <td>Telefono(10 digitos):</td>
  <td><input name="Telefono" type="text" maxlength="10" minlength="10" oninput="this.value = this.value.toUpperCase()" pattern="[0-9]+" title="Este campo solo debe contener números."required /></td>
</tr>


<tr>

<td>Transporte:</td>
<td><select name="selectTransporte" required>
    <option value="Si">SI</option>
    <option value="No">No</option>

  </select></td>

<td>Comentarios:</td>
<td><textarea name="comentarios" type="text" maxlength="50" placeholder="comentarios" oninput="this.value = this.value.toUpperCase()" required></textarea> </td>
</tr>


<tr>

    <td>Camisa:</td>
    <td><select name="selectCamisa" id="selectCamisa" required>
        <option value="Si">SI</option>
        <option value="No">No</option>
    
      </select></td>


</tr>



<tr id="campoTalla" style="display: none;">
    <td>Talla:</td>
    <td><select id="selectTalla" name="selectTalla">
        <option value="chica">Chica</option>
        <option value="mediana">Mediana</option>
        <option value="grande">Grande</option>
    </select></td>
</tr>

<tr>


<td><input name="registro" type="submit" value="Enviar" required/></td>
</tr>
</table>
</form>
<style>
 h1{
            text-align: center;
            font-size: 36px;
            margin-top: 2%;
        }

table {
    width: 50%;
    margin: 20px auto;
    border-collapse: collapse;
    background-color: #ffffff80;
}

table, th, td {
    border: 2px solid rgba(221, 234, 240, 0.082);
}

td {
    padding: 10px;
}

input[type="text"],
input[type="number"],
select,
textarea {
    width: 100%;
    padding: 8px;
    margin: 4px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

select {
    cursor: pointer;
}

textarea {
    height: 100px;
}

input[type="submit"] {
    background-color: #4caf50;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #45a049;
}
  </style>
</table>
</center>
<script src="registro.js" defer></script>
</body>
</html>

<?php

if(isset($_POST['registro'])){

$nombre=$_POST['nombre'];
$Apellido=$_POST['Apellido'];
$edad=$_POST['edad'];
$selectSexo=$_POST['selectSexo'];
$selectCiudad=$_POST['selectCiudad'];
$Telefono=$_POST['Telefono'];
$selectTransporte=$_POST['selectTransporte'];
$comentarios=$_POST['comentarios'];
$selectCamisa=$_POST['selectCamisa'];
$selectTalla=$_POST['selectTalla'];
$guardar = "INSERT INTO datos (nombre, apellido, edad, selectSexo, selectCiudad, telefono, selectTransporte, comentarios, selectCamisa, selectTalla)VALUES ('$nombre','$Apellido','$edad','$selectSexo','$selectCiudad','$Telefono','$selectTransporte','$comentarios','$selectCamisa','$selectTalla')";


$resultado = mysqli_query($conexion, $guardar);
if ($resultado) {
    echo "<script type='text/javascript'>alert('Registro exitoso');</script>";
} else {
    echo "Error: " . $guardar . "<br>" . mysqli_error($conexion);
}


}
?>
